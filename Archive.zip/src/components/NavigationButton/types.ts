export interface INavigartionButtonProps {
  title: string;
  screenLink: string;
}
