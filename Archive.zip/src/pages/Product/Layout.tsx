export const Layout = (): JSX.Element => {
  return (
    <div
      style={{
        flex: 1,
        height: "100%",
        width: "100%",
        backgroundColor: "red",
      }}
    >
      <h1>Tela de produto</h1>
    </div>
  );
};
